import React, { Fragment, useEffect, useState } from "react";
import useProductsContext from "../hooks/useProductsContext.jsx";
import "./EditProducts.css";

const EditProducts = () => {
  const {
    productsList,
    product,
    initialProductValue,
    selectProduct,
    updateProduct,
  } = useProductsContext();

  const [selectedProduct, setSelectedProduct] = useState(initialProductValue);

  const changeSelected = async (e) => {
    await selectProduct(e.target.id);
  };

  const changeData = (e) => {
    setSelectedProduct((prevSelectedProduct) => ({
      ...prevSelectedProduct,
      [e.target.name]: e.target.value,
    }));
  };

  useEffect(() => {
    setSelectedProduct(product[0]);
  }, [product]);

  return (
    <Fragment>
      <h2>Editar productos</h2>
      <article id="EditProductsContainer">
        <div
          id="editContent"
          onClick={(e) => {
            if (e.target.classList.contains("listedProduct")) {
              changeSelected(e);
            }
          }}
        >
          {productsList.length
            ? productsList.map((value) => {
                return (
                  <div id={value.id} key={value.id} className="listedProduct">
                    {value.maker} {value.name}
                  </div>
                );
              })
            : situation}
        </div>
        {selectedProduct ? (
          <div>
            <form id="EditProductForm">
              <div>
                <label htmlFor="name">Nombre: </label>
                <input
                  type="text"
                  name="name"
                  value={selectedProduct.name ? selectedProduct.name : ""}
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
              </div>
              <div>
                <label htmlFor="price">Precio: </label>
                <input
                  type="number"
                  min="0"
                  name="price"
                  step="0.01"
                  value={selectedProduct.price ? selectedProduct.price : ""}
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
              </div>
              <div>
                <label htmlFor="description">Descripción</label>
                <input
                  type="text"
                  name="description"
                  value={
                    selectedProduct.description
                      ? selectedProduct.description
                      : ""
                  }
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
              </div>
              <div>
                <label htmlFor="maker">Fabricante: </label>
                <input
                  type="text"
                  value={selectedProduct.maker ? selectedProduct.maker : ""}
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
                <p>Nvidia o AMD</p>
              </div>
              <div>
                <label htmlFor="serie">Serie: </label>
                <input
                  type="number"
                  name="serie"
                  min="0"
                  value={selectedProduct.serie ? selectedProduct.serie : ""}
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
              </div>
              <div>
                <label htmlFor="seller">Vendedor: </label>
                <input
                  type="text"
                  name="seller"
                  value={selectedProduct.seller ? selectedProduct.seller : ""}
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
              </div>
              <div>
                <label htmlFor="image">Imagen: </label>
                <input
                  type="url"
                  name="image"
                  value={selectedProduct.image ? selectedProduct.image : ""}
                  onChange={(e) => {
                    changeData(e);
                  }}
                />
              </div>
              <input
                type="button"
                value="Aplicar modificaciones"
                onClick={() => {
                  updateProduct(selectedProduct);
                }}
              />
              {selectedProduct.image ? (
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  id="editProductImage"
                />
              ) : (
                <p>Imagen no encontrada</p>
              )}
            </form>
          </div>
        ) : (
          <div>"Selecciona un producto"</div>
        )}
      </article>
    </Fragment>
  );
};
export default EditProducts;
