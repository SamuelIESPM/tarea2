import React, { Fragment, useState } from "react";
import useProductsContext from "../hooks/useProductsContext.jsx";
import ModalConfirmation from "./ModalConfirmation.jsx";
import "./DeleteProducts.css";

const DeleteProducts = () => {
  const {
    selectProduct,
    setProduct,
    product,
    initialProductValue,
    deleteProduct,
    productsList,
    situation,
  } = useProductsContext();

  const [showModal, setShowModal] = useState(false);

  const confirm = () => {
    deleteProduct(product[0].id);
    setProduct(initialProductValue);
    setShowModal(false);
  };

  const cancel = async () => {
    await setProduct(initialProductValue);
    setShowModal(false);
  };

  const selectElement = async (e) => {
    await selectProduct(e.target.id);
    setShowModal(true);
  };

  return (
    <Fragment>
      <div id="deleteContent">
        <div
          id="listDeleteProducts"
          onClick={(e) => {
            if (e.target.classList.contains("listedProduct")) {
              selectElement(e);
            }
          }}
        >
          {productsList.length
            ? productsList.map((value) => {
                return (
                  <div id={value.id} key={value.id} className="listedProduct">
                    {value.maker} {value.name}
                  </div>
                );
              })
            : situation}
        </div>
      </div>
      {showModal && (
        <ModalConfirmation
          message="¿Estás seguro de que deseas eliminar el elemento?"
          onAccept={confirm}
          onCancel={cancel}
        />
      )}
    </Fragment>
  );
};

export default DeleteProducts;
