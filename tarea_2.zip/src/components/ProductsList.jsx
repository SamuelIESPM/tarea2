"use strict";
import React, { Fragment } from "react";
import useProductsContext from "../hooks/useProductsContext.jsx";
import ProductList from "./ProductList.jsx";
import "./ProductsList.css";

const ProductsList = () => {
  const {
    productsList,
    getProducts,
    situation,
    orderProducts,
    searchProduct,
    maxPrice,
    product,
  } = useProductsContext();
  return (
    <Fragment>
      <h2>Listado de productos</h2>
      <div className="filters">
        <p>Filtrar:</p>
        <button
          onClick={() => {
            getProducts();
          }}
        >
          Recargar productos
        </button>
        <button
          onClick={() => {
            orderProducts(true);
          }}
        >
          Ordenar por nombre ascendente
        </button>
        <button
          onClick={() => {
            orderProducts(false);
          }}
        >
          Ordenar por nombre descendente
        </button>
        <input
          type="search"
          placeholder="Buscar..."
          onChange={(e) => {
            e ? searchProduct(e.target.value) : getProducts();
          }}
        />
        <input
          type="number"
          placeholder="Prexio máximo..."
          min={0}
          step="any"
          onChange={(e) => {
            e ? maxPrice(e.target.value) : getProducts();
          }}
        />
      </div>
      <div id="content">
        <div id="displayProducts">
          {productsList.length
            ? productsList.map((value) => {
                return <ProductList key={value.id} data={value} />;
              })
            : situation}
        </div>
        <div id="info">
          {product ? (
            <img src={product.image} alt="" />
          ) : (
            <div>"Selecciona un producto"</div>
          )}
        </div>
      </div>
    </Fragment>
  );
};

export default ProductsList;
