"use strict";
import { Fragment } from "react";
import "./Header.css";

const Header = () => {
  return (
    <Fragment>
      <header>
        <h1>Recuperación Tarea 2</h1>
      </header>
    </Fragment>
  );
};

export default Header;
